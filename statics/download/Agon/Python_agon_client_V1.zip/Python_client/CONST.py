import math

MAX_ROUND = 150.0


class ServerSocket:
    SERVER_HOST = '0.0.0.0'
    SERVER_PORT = 5000
    CLIENT_NUMBER = CLIENT_SOCKET_NUMBER = 2
    TIME_OUT = 400
    MAX_DATA_RECV_SIZE = 2048
    MAX_DATA_SEND_SIZE = 2048
    TIME_RECV = 60


class EstablishConnection:
    DEFAULT_PASSWORD = 0
    STATUS_ACCEPTED = "DONE"
    SERVER_MSG = {"ID": "", "Password": DEFAULT_PASSWORD}
    CLIENT_MSG = {"Status": "", "Password": DEFAULT_PASSWORD, "Name": ""}


class IOMsg:
    DEFAULT_PASSWORD = 0
    SERVER_INPUT_MSG = {"Piece": "", "Move_To": "", "Password": DEFAULT_PASSWORD, "ID": 0}
    SERVER_OUTPUT_MSG = {"Piece": "", "Move_To": "", "ID": 0}
    NOTIFICATION_MSG = {"ID": -2}
    MassageID = {-1: "MSG is empty",
                 0: "Start massage",
                 1: "Player 1 move",
                 2: "Player 2 move",
                 3: "ID incorrect",
                 4: "Wrong move",
                 5: "Done massage"}


def convert_coordinate(coordinate):
    if type(coordinate) == str and coordinate != "":
        return [int(coordinate[0:2]), int(coordinate[2:4])]
    elif type(coordinate) == list or type(coordinate) == tuple:
        result = ''
        for i in coordinate:
            if i != 0:
                result += str(i) if math.log10(i) >= 1 else '0' + str(i)
            else:
                result += "00"
        return result
    else:
        return ""
