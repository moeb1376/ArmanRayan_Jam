import CONST


class DataManger:
    def __init__(self, name):
        self.is_updated = 0
        self.wm_temp = {"Move_TO": "", "Piece": ""}
        self.wm = []
        self.player_number = 0
        self.player_name = name
        self.game_start = False
        self.game_done = False
        self.error_number = 0

    def update(self, WM):
        ID = WM.get("ID", "")
        if ID == 0:
            if self.player_number == 1:
                self.is_updated += 1
            if WM.keys() == CONST.IOMsg.SERVER_OUTPUT_MSG.keys():
                self.create_wm(WM)
        elif ID == 5:
            self.game_done = True
        elif ID == 3 or ID == 4:
            self.error_number = ID
        elif ID != '':
            self.is_updated += 1
            self.error_number = 0
            if WM.keys() == CONST.IOMsg.SERVER_OUTPUT_MSG.keys():
                self.create_wm(WM)

    def get_wm(self):
        self.is_updated -= 1
        return self.wm.pop()

    def get_updated(self):
        return self.is_updated

    def set_player_number(self, number):
        self.player_number = number

    def create_wm(self, msg):
        self.wm_temp["Move_To"] = CONST.convert_coordinate(msg.get("Move_To", ''))
        self.wm_temp["Piece"] = CONST.convert_coordinate(msg.get("Piece", ""))
        self.wm.append(self.wm_temp.copy())
