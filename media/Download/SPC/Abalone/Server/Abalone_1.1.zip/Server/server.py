import logic_manager
import io_manager
import graphic_manager
import CONST
import os
import datetime


class GameManager:
    def __init__(self):
        self.graphic_manager = graphic_manager.GraphicManager()
        self.io_manager = io_manager.IOManager(self.graphic_manager)
        self.logic_manager = logic_manager.LogicManager()
        self.game_finish = -1
        self.BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.log_file = open(os.path.join(
            self.BASE_DIR, datetime.datetime.now().strftime("%y-%m-%d_%H%M%S")) + '.AbaloneLog', 'w')

    def start(self):
        self.io_manager.init_IO()
        self.log_file.write(
            self.io_manager.input_manager[0].name + '|' + self.io_manager.input_manager[1].name + '\n')
        output = self.logic_manager.build_output(ID=0)
        self.logic_manager.calculate_points()
        print("First output:", output)
        self.io_manager.set_output(output)
        while self.game_finish == -1:
            try:
                flag = True
                index = int(self.logic_manager.round // 0.5) % 2
                while flag and self.io_manager.input_manager[index].spend_time < CONST.ServerSocket.MAX_TIME_RECV:
                    input = self.io_manager.get_input()
                    print("input:", input)
                    output = self.logic_manager.play(input)
                    print("output : ", output)
                    if output.get("Last_Change", {}).get("ID", -2) == 1 or \
                            output.get("Last_Change", {}).get("ID", -2) == 2:
                        self.logic_manager.round += 0.5
                        self.io_manager.change_input_turn()
                        self.log_file.write(self.creat_log_line(
                            output.get("Last_Change", {})) + '\n')
                        flag = False
                    else:
                        self.io_manager.set_output(output, index)
                    print("Spend Time : ", self.io_manager.input_manager[0].number,
                          self.io_manager.input_manager[0].spend_time,
                          self.io_manager.input_manager[1].number,
                          self.io_manager.input_manager[1].spend_time,
                          self.logic_manager.round)
                self.game_finish = self.logic_manager.check_game_finish()
                self.graphic_manager.draw_points(self.logic_manager.player_points)
                self.graphic_manager.draw_marble_out(
                    (14 - len(self.logic_manager.player_marbles[0]), 14 - len(self.logic_manager.player_marbles[1])))
                if self.game_finish == -1:
                    if round(self.io_manager.input_manager[1].spend_time, 3) >= CONST.ServerSocket.MAX_TIME_RECV:
                        self.game_finish = 1
                    if round(self.io_manager.input_manager[0].spend_time, 3) >= CONST.ServerSocket.MAX_TIME_RECV:
                        self.game_finish = 2
                if self.game_finish == -1:
                    if self.logic_manager.round < CONST.Game.MAX_ROUND:
                        self.io_manager.set_output(output)
            except Exception as e:
                print("Game Error")
                raise
        msg = 'Player %d (%s) is Win'
        if self.game_finish == 0:
            print("Draw")
            self.log_file.write('Draw' + '\n')
        elif self.game_finish == 1:
            print(msg % (1, self.io_manager.input_manager[0].name))
            self.log_file.write(msg % (1, self.io_manager.input_manager[0].name) + '\n')
        elif self.game_finish == 2:
            print(msg % (2, self.io_manager.input_manager[1].name))
            self.log_file.write(msg % (2, self.io_manager.input_manager[1].name) + '\n')
        self.io_manager.set_output({"ID": 5})
        self.log_file.close()

    def creat_log_line(self, last_change):
        result = []
        keys = sorted(last_change.keys())
        keys.remove('ID')
        for i in keys:
            result.append(last_change[i])
        return '|'.join(result)


if __name__ == "__main__":
    game_manager = GameManager()
    game_manager.start()
    input("press any key to continue")
