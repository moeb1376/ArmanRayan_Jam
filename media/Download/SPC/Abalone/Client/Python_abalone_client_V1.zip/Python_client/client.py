import time

import data_manager
import io_manager


class AI:
    def __init__(self, name=None):
        self.dm = data_manager.DataManger(name)
        self.io_manager = io_manager.IOManager(self.dm)

    def do_turn(self):
        #AI
        pass


if __name__ == "__main__":
    ai = AI('s')
    while not ai.dm.game_start:
        continue
    print("Game Start ", 1 if ai.dm.player_number == 1 else 2)
    print(ai.dm.get_updated())
    while not ai.dm.game_done:
        if ai.dm.get_updated() or ai.dm.error_number != 0:
            ai.do_turn()
