import json
import socket
import threading

import CONST


class IOManager:
    def __init__(self, dm):
        self.dm = dm
        self.client_socket = socket.socket()
        self.thread = threading.Thread(target=self.recv)
        self.thread.start()
        self.authorisation = {}

    def recv(self):
        self.client_socket.connect((CONST.ServerSocket.SERVER_HOST, CONST.ServerSocket.SERVER_PORT))
        recv_data = self.client_socket.recv(CONST.ServerSocket.MAX_DATA_RECV_SIZE)
        try:
            self.authorisation = json.loads(recv_data.decode("ascii"))
        except:
            print("Server msg output is not json")
        msg = {"Status": CONST.EstablishConnection.STATUS_ACCEPTED,
               "Password": self.authorisation.get("Password", CONST.EstablishConnection.DEFAULT_PASSWORD),
               "Name": self.dm.player_name}
        self.client_socket.sendall(json.dumps(msg).encode("ascii"))
        print(self.authorisation)
        self.dm.set_player_number(self.authorisation["ID"])
        decode = {}
        while decode != {"ID": 5}:
            recv_data = self.client_socket.recv(CONST.ServerSocket.MAX_DATA_RECV_SIZE)
            try:
                decode = json.loads(recv_data.decode("ascii"))
            except:
                pass
            else:
                if decode.get("ID", -2) == 0:
                    self.dm.game_start = True
                    print('Start Massage',decode)
                    self.dm.update(decode)
                else:
                    self.dm.update(decode)
                    print('Decode', decode)
        print("********************___The End___********************")
        self.dm.game_done = True
        self.client_socket.close()

    def move(self, **kwargs):
        print("Kwargs", kwargs)
        msg = {"Password": self.authorisation.get("Password", CONST.EstablishConnection.DEFAULT_PASSWORD),
               "ID": self.dm.player_number}
        keys = list(CONST.IOMsg.SERVER_INPUT_MSG.keys())
        del keys[keys.index("Password")]
        del keys[keys.index("ID")]
        print('keys : ', keys)
        for i in keys:
            msg[i] = CONST.convert_coordinate(kwargs.get(i, ""))
        print('msg', msg)
        self.client_socket.sendall(json.dumps(msg).encode("ascii"))
