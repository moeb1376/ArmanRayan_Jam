import logic_manager
import io_manager
import graphic_manager
import CONST


class GameManager:
    def __init__(self):
        self.logic_manager = logic_manager.LogicManager()
        self.graphic_manager = graphic_manager.GraphicManager(self.logic_manager.game_board.board)
        self.io_manager = io_manager.IOManager(self.graphic_manager)
        self.game_finish = -1
        self.log_file = open('LOG.AgonLog', 'w')

    def start(self):
        self.io_manager.init_IO()
        self.log_file.write(self.io_manager.input_manager[0].name + '|' + self.io_manager.input_manager[1].name + '\n')
        self.io_manager.set_game_start()
        while self.game_finish == -1:
            try:
                flag = True
                index = int(self.logic_manager.round // 0.5) % 2
                while flag and round(self.io_manager.input_manager[index].spend_time, 3) < CONST.ServerSocket.TIME_RECV:
                    io_input = self.io_manager.get_input()
                    print("input:", io_input)
                    output = self.logic_manager.play(io_input)
                    if output['ID'] == 1 or output['ID'] == 2:
                        self.logic_manager.round += 0.5
                        self.io_manager.change_input_turn()
                        print("output : ", output)
                        print('Round = ', self.logic_manager.round)
                        self.log_file.write(self.create_log_line(output) + '\n')
                        flag = False
                    else:
                        self.io_manager.set_output(output, index)
                print("Spend Time : ", self.io_manager.input_manager[0].number, ':',
                      round(self.io_manager.input_manager[0].spend_time, 3),
                      self.io_manager.input_manager[1].number, ':',
                      round(self.io_manager.input_manager[1].spend_time, 3))
                if self.logic_manager.round < CONST.MAX_ROUND:
                    self.io_manager.set_output(output)
                self.graphic_manager.draw_points(self.logic_manager.final_points)
                self.game_finish = self.logic_manager.check_game_finish()
                if self.game_finish == -1:
                    if round(self.io_manager.input_manager[1].spend_time, 3) >= CONST.ServerSocket.TIME_RECV:
                        self.game_finish = 1
                    if round(self.io_manager.input_manager[0].spend_time, 3) >= CONST.ServerSocket.TIME_RECV:
                        self.game_finish = 2
                print(self.game_finish)
            except Exception as e:
                print("Game Error\n", e)
                raise
        msg = 'Player %d (%s) is Win'
        if self.game_finish == 0:
            print("Draw")
            self.log_file.write('Draw' + '\n')
        elif self.game_finish == 1:
            print(msg % (1, self.io_manager.input_manager[0].name))
            self.log_file.write(msg % (1, self.io_manager.input_manager[0].name) + '\n')
        elif self.game_finish == 2:
            print(msg % (2, self.io_manager.input_manager[1].name))
            self.log_file.write(msg % (2, self.io_manager.input_manager[1].name) + '\n')
        self.io_manager.set_output({"ID": 5})
        self.log_file.close()

    @staticmethod
    def create_log_line(last_change):
        result = []
        keys = sorted(last_change.keys())
        keys.remove('ID')
        for i in keys:
            result.append(last_change[i])
        return '|'.join(result)


if __name__ == "__main__":
    game_manager = GameManager()
    game_manager.start()
    input("press any key to continue")
