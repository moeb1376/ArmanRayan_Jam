import CONST


class LogicManager:
    def __init__(self):
        self.game_board = AgonBoard()
        self.last_change = CONST.IOMsg.SERVER_OUTPUT_MSG
        self.player_pieces = self.game_board.get_player_piece()
        self.turn = 1
        self.player_points = [0, 0]
        self.final_points = [0, 0]
        self.round = 0.0

    def play(self, client_input):
        if client_input == CONST.IOMsg.SERVER_INPUT_MSG:
            print("MSG is empty")
            return self.build_output(ID=-1)
        player_id = client_input["ID"]
        if player_id != self.turn:
            print("ID player", player_id, "is not correct")
            return self.build_output(ID=3)
        if self.forfeit_turn_msg(client_input):
            print('forfeit msg')
            return self.build_output(client_input, ID=int(self.round / 0.5 % 2 + 1))
        piece = client_input['Piece']
        piece = CONST.convert_coordinate(piece)
        move = client_input["Move_To"]
        move = CONST.convert_coordinate(move)
        selected_piece = self.game_board.get_data(piece)
        if not self.game_board.check_point(piece) or not self.game_board.check_point(move):
            return self.build_output(ID=4)
        if not self.check_cell_is_empty(move) or self.check_cell_is_empty(piece):
            print("cell is not empty")
            return self.build_output(ID=4)
        if self.check_cell_is_trap(move, player_id):
            print("cell is trap")
            return self.build_output(ID=4)
        if selected_piece[-1] != str(player_id):
            print("choose piece is not correct")
            return self.build_output(ID=4)
        pieces_captured_list = self.get_capture_piece(player_id)
        if len(pieces_captured_list) > 0:
            print("Capture list player ", player_id, pieces_captured_list)
            if pieces_captured_list.get(piece, 0) == 0:
                print("choose piece is not capture piece")
                return self.build_output(ID=4)
            if 'q' + str(player_id) in pieces_captured_list.values() and selected_piece != 'q' + str(player_id):
                print('first move captured queen')
                return self.build_output(ID=4)
            if selected_piece == 's' + str(player_id):
                if self.game_board.get_circle_number(move) < 5:
                    print('captured soldier should be move to outer rings')
                    return self.build_output(ID=4)
        if len(pieces_captured_list) == 0:
            if self.game_board.get_circle_number(move) > self.game_board.get_circle_number(piece):
                print("Move isn't forwarding")
                return self.build_output(ID=4)
            if move not in self.game_board.get_neighbours(piece):
                print("Cell is not neighbours", move, piece, '\n', self.game_board.get_neighbours(piece))
                return self.build_output(ID=4)
        if 's' + str(player_id) == selected_piece and move == [5, 5]:
            print("Soldier could'n move to central cell ")
            return self.build_output(ID=4)
        if len(pieces_captured_list) > 0:
            self.player_points[player_id % 2] += 10 if 'q' + str(player_id) in pieces_captured_list.values() else 5
        self.game_board.set_data(move, selected_piece)
        self.game_board.set_data(piece, 0)
        self.player_pieces[player_id - 1].append(move)
        del self.player_pieces[player_id - 1][self.player_pieces[player_id - 1].index(piece)]
        return self.build_output(client_input, ID=int(self.round / 0.5 % 2 + 1))

    def build_output(self, last_change=CONST.IOMsg.SERVER_OUTPUT_MSG, **kwargs):
        if kwargs.get('ID') == 2 or kwargs.get('ID') == 1:
            self.turn = (self.turn % 2) + 1
            result = {}
            for i in CONST.IOMsg.SERVER_OUTPUT_MSG.keys():
                if i != "Password":
                    result[i] = last_change.get(i, "")
            with open('../Logviewer/LOG.AgonLog', 'a') as f:
                f.write(str(result) + '\n')
            return result
        else:
            return {"ID": kwargs.get('ID')}

    @staticmethod
    def forfeit_turn_msg(msg):
        if msg['Piece'] == "" and msg['Move_To'] == "":
            return True
        else:
            return False

    def check_cell_is_empty(self, point):
        return self.game_board.get_data(point) == 0

    def check_cell_is_trap(self, point, player_id):
        if self.game_board.get_circle_number(point) == 5:
            return False
        related_neighbours = self.get_related_neighbours(point)
        for i in related_neighbours:
            if len(i) < 2:
                continue
            if i[0] == 0 or i[1] == 0:
                continue
            if i[0][-1] == i[1][-1] and i[0][-1] != str(player_id):
                return True
        return False

    def get_related_neighbours(self, point):
        neighbours = self.game_board.get_neighbours(point)
        result = [[], [], []]
        for i in neighbours:
            data = self.game_board.get_data(i)
            if i[0] == point[0]:
                result[0].append(data)
            elif i[1] == point[1]:
                result[1].append(data)
            else:
                result[2].append(data)
        return result

    def get_capture_piece(self, player_id):
        result = MyDict()
        for i in self.player_pieces[player_id - 1]:
            if self.check_cell_is_trap(i, player_id):
                if self.game_board.get_circle_number(i) < 5:
                    result[i] = self.game_board.get_data(i)
        return result

    def check_game_finish(self):
        self.calculate_points()
        neighbour = self.game_board.get_neighbours((5, 5))
        center_data = self.game_board.get_data((5, 5))
        check_player = [0, 0]
        for i in neighbour:
            data = self.game_board.get_data(i)
            if data == 0:
                return -1 if self.round < CONST.MAX_ROUND else self.max_final_point() + 1
            elif data == 's1':
                check_player[0] += 1
            elif data == 's2':
                check_player[1] += 1
        if check_player[0] != 6 and check_player[1] != 6:
            return -1 if self.round < CONST.MAX_ROUND else self.max_final_point() + 1
        elif check_player[0] == 6 and center_data == 'q1':
            return 1
        elif check_player[1] == 6 and center_data == 'q2':
            return 2
        elif (check_player[0] == 6 or check_player[1] == 6) and center_data == 0:
            return 1 if check_player[1] == 6 else 2
        else:
            return -1 if self.round < CONST.MAX_ROUND else self.max_final_point() + 1

    def max_final_point(self):
        temp = max(self.final_points)
        if self.final_points.count(temp) == 1:
            return self.final_points.index(temp)
        else:
            return -1

    def calculate_points(self):
        temp = [0, 0]
        for i in range(len(self.player_pieces)):
            for j in self.player_pieces[i]:
                data = self.game_board.get_data(j)
                circle_number = self.game_board.get_circle_number(j)
                circle_number = abs(circle_number - 6)
                temp[i] += circle_number * 20 if 'q' in data else circle_number * 10
        for i in range(2):
            self.final_points[i] = temp[i] + self.player_points[i]


class AgonBoard:
    def __init__(self):
        self.board = self.create_board()
        self.initial_start_game()

    @staticmethod
    def create_board():
        result = [[0 for _ in range(11)] for _ in range(11)]
        for i in range(5):
            for j in range(6 + i, 11):
                result[i][j] = -1
        for i in range(6, 11):
            for j in range(i - 6, i - i - 1, -1):
                result[i][j] = -1
        return result

    def initial_start_game(self):
        self.board[1][0] = 's2'
        self.board[3][0] = 's1'
        self.board[5][0] = 'q2'
        self.board[7][2] = 's1'
        self.board[9][4] = 's2'
        self.board[10][6] = 's1'
        self.board[9][10] = 's1'
        self.board[10][9] = "s2"
        self.board[7][10] = 's2'
        self.board[5][10] = 'q1'
        self.board[3][8] = 's2'
        self.board[1][6] = 's1'
        self.board[0][4] = 's2'
        self.board[0][1] = 's1'

    def get_neighbours(self, point):
        result = [[point[0], point[1] + 1], [point[0], point[1] - 1],
                  [point[0] + 1, point[1] + 1], [point[0] - 1, point[1] - 1],
                  [point[0] - 1, point[1]], [point[0] + 1, point[1]]]
        i = 0
        while i < len(result):
            if self.check_point(result[i], False):
                i += 1
            else:
                del result[i]
        return result

    def check_point(self, point, log=True):
        if not (0 <= point[0] < 11 and 0 <= point[1] < 11):
            if log:
                print("Point: ", point, "is not correct (out of range)")
            return False
        elif self.board[point[0]][point[1]] == -1:
            if log:
                print("Point is not correct(out of board)")
            return False
        else:
            return True

    @staticmethod
    def get_distance(point1, point2):
        return (point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2

    def get_circle_number(self, point):
        x, y = point
        if not self.check_point(point):
            return -1
        for i in range(5):
            if x == 10 - i or x == 0 + i or y == 0 + i or y == 10 - i or y == x + 5 - i or y == x - 5 + i:
                return 5 - i
        return 0

    def get_data(self, point):
        x, y = point
        return self.board[x][y]

    def get_player_piece(self):
        result = [[], []]
        for i in range(11):
            for j in range(11):
                data = self.board[i][j]
                if data == -1 or data == 0:
                    continue
                elif int(data[-1]) == 1:
                    result[0].append([i, j])
                else:
                    result[1].append([i, j])
        return result

    def set_data(self, point, value):
        x, y = point
        self.board[x][y] = value


class MyDict:
    def __init__(self):
        self.dic = {}

    def __getitem__(self, item):
        if type(item) == list:
            return self.dic[str(item)]
        return self.dic[item]

    def __setitem__(self, key, value):
        if type(key) == list:
            self.dic[str(key)] = value
        else:
            self.dic[key] = value

    def __len__(self):
        return len(self.dic)

    def get(self, key, default=None):
        if type(key) == list:
            if str(key) in self.dic.keys():
                return self.dic[str(key)]
        else:
            if key in self.dic.keys():
                return self.dic[key]
        return default

    def values(self):
        return self.dic.values()

    def __str__(self):
        return str(self.dic)
