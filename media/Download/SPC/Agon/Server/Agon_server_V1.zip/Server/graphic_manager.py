import pygame
import sys
import CONST
import time

black = (0, 0, 0)
white = (255, 255, 255)


class GraphicManager:
    def __init__(self, board_data):
        pygame.init()
        self.display_width = 600
        self.display_height = 519
        self.menu_width = 800
        self.menu_height = 400
        self.menu_surface = None
        self.name = []
        self.surface = None
        self.board = pygame.image.load("Agon_board.png")
        self.WQ = pygame.image.load("WQ.png")
        self.WS = pygame.image.load('WS.png')
        self.BQ = pygame.image.load('BQ.png')
        self.BS = pygame.image.load('BS.png')
        self.board_data = board_data
        self.points_rect = [0, 0]

    def set_output(self, msg):
        if msg != CONST.IOMsg.SERVER_OUTPUT_MSG:
            self.draw(self.board_data)

    def draw_name(self, name1, name2):
        font = pygame.font.Font("IMMORTAL.ttf", 18)
        text_surface = font.render(name2, 1, (255, 255, 255), (0, 0, 0))
        text_rect = text_surface.get_rect()
        text_rect.topright = (self.display_width - 1, 0)
        shape_rect = self.BS.get_rect()
        shape_rect.topright = text_rect.bottomright
        self.points_rect[1] = shape_rect.bottomright
        self.surface.blit(text_surface, text_rect)
        self.surface.blit(self.BS, shape_rect)
        text_surface = font.render(name1, 1, (255, 255, 255), (0, 0, 0))
        text_rect = text_surface.get_rect()
        text_rect.topleft = (0, 0)
        shape_rect = self.WS.get_rect()
        shape_rect.topleft = text_rect.bottomleft
        self.points_rect[0] = shape_rect.bottomleft
        self.surface.blit(self.WS, shape_rect)
        self.surface.blit(text_surface, text_rect)

    @staticmethod
    def exit_game():
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    pygame.display.quit()
                    sys.exit()
            if event.type == pygame.QUIT:
                pygame.quit()
                pygame.display.quit()
                sys.exit()

    def draw(self, board):
        self.surface.blit(self.board, (0, 0))
        self.draw_name(self.name[0], self.name[1])
        self.draw_pieces(board)
        pygame.display.update()
        self.exit_game()

    def draw_pieces(self, board):
        y = [i for i in range(450, 19, -43)]
        x = [i for i in range(152, 26, -25)]
        x.extend([i for i in range(52, 153, 25)])
        for i in range(len(board)):
            for j in range(len(board[i])):
                data = board[i][j]
                r = 25 * abs(5 - j) + 50 * (i - abs(5 - j)) + 27 if j > 5 else 25 * abs(5 - j) + 50 * i + 27
                if data == 's1':
                    color = self.WS
                elif data == "s2":
                    color = self.BS
                elif data == "q1":
                    color = self.WQ
                elif data == 'q2':
                    color = self.BQ
                else:
                    color = None
                if color is not None:
                    self.surface.blit(color, (r, y[j]))

    def draw_menu(self):
        self.menu_surface = pygame.display.set_mode((self.menu_width, self.menu_height))
        self.menu_surface.fill((3, 155, 229))
        pygame.display.update()
        font = pygame.font.Font("freesansbold.ttf", 30)
        text_surface = font.render("Waiting...", 1, black, white)
        text_rect = text_surface.get_rect()
        text_rect.center = (self.menu_width / 2, self.menu_height / 4)
        self.menu_surface.blit(text_surface, text_rect)
        text_rect.center = (self.menu_width / 2, self.menu_height / 4 * 3)
        self.menu_surface.blit(text_surface, text_rect)
        pygame.display.update()

    def draw_menu_name(self, text):
        self.name.append(text)
        font = pygame.font.Font("freesansbold.ttf", 30)
        text_surface = font.render(text + " is connected", 1, black, white)
        text_rect = text_surface.get_rect()
        center_temp = self.menu_height / 4 if len(self.name) == 1 else self.menu_height / 4 * 3
        text_rect.center = (self.menu_width / 2, center_temp)
        pygame.draw.rect(self.menu_surface, (3, 155, 229), (0, center_temp - 50, self.menu_width, center_temp + 50))
        self.menu_surface.blit(text_surface, text_rect)
        pygame.display.flip()
        if len(self.name) == 2:
            text_surface = font.render("Game Is Loading ...", 1, (244, 81, 30), white)
            text_rect = text_surface.get_rect()
            text_rect.center = (self.menu_width / 2, self.menu_height / 2)
            self.menu_surface.blit(text_surface, text_rect)
            pygame.display.update()
            self.surface = pygame.display.set_mode((self.display_width, self.display_height))
            pygame.display.set_caption('Agon')
            pygame.display.update()

    def draw_points(self, points):
        font = pygame.font.Font("IMMORTAL.ttf", 18)
        text_surface = font.render(str(points[0]), 1, (255, 255, 255), (0, 0, 0))
        text_rect = text_surface.get_rect()
        text_rect.topleft = self.points_rect[0]
        self.surface.blit(text_surface, text_rect)
        text_surface = font.render(str(points[1]), 1, (255, 255, 255), (0, 0, 0))
        text_rect = text_surface.get_rect()
        text_rect.topright = self.points_rect[1]
        self.surface.blit(text_surface, text_rect)
